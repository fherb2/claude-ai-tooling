# correct-zaaack-md-editor-mistakes — find and repair damaged whitespace in Markdown tables

*Last updated: 2026-09-15*

*[Deutsche Fassung](https://github.com/fherb2/claude-ai-tooling/blob/master/skills/correct-zaaack-md-editor-mistakes/README.md)*

✅☑ **Finished and usable, in both language versions.** Tools, skill text and silent trigger are in place, the frontmatter is set. What is still open is stated in the closing section — none of it stands in the way of use. — Usable with Claude Code.

## Overview

**Some WYSIWYG editors for Markdown damage the tables of the file they are editing when saving. This skill lets Claude find and repair that damage on its own, without the user having to point it out on every occasion.** The behavior was observed on `zaaack.markdown-editor` for VSCode; the tools, however, do not ask about the editor but about the damage, and are therefore not tied to it.

The skill does three things. It lets Claude recognize the artifacts as soon as they first show up. It obtains a standing authorization from the user so that the repair afterwards runs without asking — otherwise Claude, by its other rules, puts every file change up for a decision first, and there would be no automation at all. And it puts the outcome on record in the project memory, so the question is not asked afresh in every session.

**Scope.** The skill does not format Markdown and does not tidy up tables. It repairs exactly two kinds of damaged whitespace in table rows and leaves everything else untouched: no word, no punctuation, no column alignment, no double blank lines. It only takes effect where Claude can read and write files; in claude.ai it is pointless, because the tools are missing and `${CLAUDE_SKILL_DIR}` is not resolved there.

## Installation

1. **Download the package.** `downloads/correct-zaaack-md-editor-mistakes_en_local.zip`

2. **Unpack it.** The archive contains a folder `correct-zaaack-md-editor-mistakes/` with all the files. Unpack it into `~/.claude/skills/` — then the skill applies to all projects — or into `.claude/skills/` in the project, then only there. An existing folder of the same name is replaced; nothing old is left behind.

   The personal location is the obvious one here: whoever uses the editor at all usually uses it everywhere. The one argument against it is `SKIP` (see "The scope") — the exception list is project-bound, and a personal installation carries the same one for all projects.

3. **Adopt the silent trigger.** You have to do this by hand. Claude then recognizes more easily from the context whether the skill should be loaded. To do it: from `CLAUDE-snippet.md`, **everything below the separator line** goes into the `CLAUDE.md` of the chosen location. The italic text above it stays behind; the file itself stays in the skill folder and shows by its date line which state the adopted trigger is from.

   Without this step the skill only takes effect when called explicitly with `/correct-zaaack-md-editor-mistakes`. That is the standard way it fails here: nobody asks of their own accord to have tables checked for spaces.

4. **Optionally set up the hook** — see "Reliability: the hook".

**The `README.md` is not an extra for this skill but a requirement.** With other skills its absence at the target location only costs depth of reasoning when questions come up; here the `SKILL.md` explicitly points to it for setting up the hook, instead of dragging the description along in the context permanently. That is why the package brings it — do not remove it.

## Details

### What the editor does

Two kinds are on record.

**Swallowed spaces** in front of an opening delimiter for inline code or bold text. Examples from this repository, before the repair:

```text
this is how it stood          this is how it must read
GNU`find`                    GNU `find`
macOS:`brew install jq`      macOS: `brew install jq`
claude.ai**und** lokal       claude.ai **und** lokal
```

Visible if you watch out for it — and easy to overlook for exactly that reason.

**These examples sit in a code block and not in a table, and that is not a matter of taste.** The tools do not tell a documented counter-example apart from a real defect: were the broken versions to sit in a table row, the scanner would take them for findings and the repair tool would repair the documentation until it showed nothing any more. That is precisely what happened while this file was being written — eleven reported "artifacts" in a file that only describes. The scanner looks at lines beginning with `|` and at nothing else; a code block is immune to it. Whoever reformats the examples brings the fault back.

**No-break spaces** (U+00A0) in place of ordinary ones. This is the worse kind: there is no difference to be seen in the rendered text and none in the editor either, but any search over the wording fails. Whoever searches for "Vorgaben automatisch" does not find the line, although it is right there. Six such characters stood in this repository, all of them in tables, none on purpose.

**What has not been measured:** whether the editor swallows spaces outside tables as well. So far artifacts have turned up in table rows only, and the tools therefore look nowhere else. Whether there are further kinds is likewise open. Whoever finds one extends `md_table_artifacts.py` — and records it here.

### The three limits — and why they are drawn where they are

They stand, with their reasons, in the docstrings of `md_table_artifacts.py`. There, because they have to be read when the core is rebuilt: all three look like sloppiness and are not.

**A space is restored only *in front of* a delimiter, never *behind* it.** A suffix glued to a code span is regular prose: `` `uuid`s `` means "several uuid" and is right as it stands. Whoever makes the rule symmetrical destroys such places. The scanner reports them under `notes`, so that a person looks them over once.

**Single-asterisk `*italic*` is not detected.** What is detected is `**bold**` and `` `code` ``. With a single asterisk the risk of confusion with list markers and multiplication signs is too great, and a wrong repair would be silent. No tool catches this gap — it is the one point where Claude has to look for itself. One such place turned up in this repository and was repaired by hand.

**Double blank lines in front of tables are not touched.** The Markdown linter reports them (`MD012`), 35 times in this repository. They do not change how the page renders, and the editor puts them back at the next save — cleaning up against that is wasted effort.

### How the tools are built

Three files, and each split has its reason.

`md_table_artifacts.py` carries the rules: what counts as an artifact, what falls within scope, how a table row is repaired, and which kinds of artifact are repairable at all. It is only ever imported, never called. **The reason is not tidiness:** before, the detection stood in both commands, and two versions of the same rule drift apart. Then the scanner reports places the repair tool does not touch — or, worse, the repair tool changes something the scanner never reported.

`scan_md_tables.py` is given **one** path and descends into every branch by itself. It never writes, so that a wrongly set switch in a hook cannot do silent damage.

`fix_md_tables.py` reads the scanner's list from `stdin` and works through the named files only.

**No state on disk.** The scanner writes its JSON to `stdout`; in the repair step it flows straight on without touching the disk. No intermediate file means: no stale list, nothing to clean up, nothing left lying around between sessions.

**The list carries paths and counts, never line numbers.** The repair tool re-reads every file anyway and derives its repairs from the current content. A line number would be stale the moment something is saved between the two runs, and would make it edit the wrong place. For the same reason the repair step runs the scanner again instead of keeping a list.

**Three lists, and the differences are the heart of the matter.** `files` is the work list and alone determines the exit code. `notes` holds what is reported but deliberately never repaired. Were the notes in the work list, the blank test could never come out clean: the exit code would stay 1 forever, and a hook would fire on every commit without there ever being anything to do. That is exactly how the first version was built.

**The third list, `unreadable`, is the refusal to abort.** A file that cannot be read no longer ends the run; it is skipped and named there. The reason is the kind of failure that arises otherwise: an abort leaves **no** result, and whoever only looks at the last line takes "nothing found" and "never ran" for the same thing — for a check meant to hold before every commit, that is the worst outcome. The list deliberately does **not** touch the exit code: it says the check was incomplete, not that something needs repair. So that it is not passed over regardless, the `SKILL.md` obliges the instance to report a non-empty list to the user.

### The scope: three limits

**Hidden entries stay out** — every path with a segment that starts with a dot, so `.git/`, `.claude/` and their like. This is counted **relative to the path given**, and that is no nicety: it is what keeps a deliberate run **into** a dot folder possible. Whoever wants to check Markdown in there — the files of a project-local skill under `.claude/skills/`, say — calls the scanner again with that folder.

**Only regular files are read.** A Bash sandbox masks the paths it must not expose by mounting a device over them: the name looks like a Markdown file, the entry is a character device, unreadable — and outside the sandbox it does not exist at all. **This is recognized by the file type, not by the shape of the mount.** That is the load-bearing decision: the shape of those mounts is not ours and may change; the file type stays the criterion. Whatever this limit does not catch, `unreadable` catches.

**`SKIP` in `md_table_artifacts.py`** names the folders excluded by name — at present only this repository's folder of retired working instructions. **This is the one project-related setting**; whoever takes the tools into another project reviews the list first. The former entry `/.git/` is gone, because the dot rule covers it.

`SKIP` sits in the core and not in the repair tool, so that the scope is not decided in two places.

### Reliability: the hook

A skill is loaded when something points to it — not with certainty. For "at every commit, without exception" that is not enough. Only a hook achieves that, because Claude Code executes it without a model having to decide in favor of it: *"certain actions always happen rather than relying on the LLM to choose to run them"* ([Automate actions with hooks](https://code.claude.com/docs/en/hooks-guide)).

The entry belongs in the project's `.claude/settings.json` — per the documentation the level that may be version-controlled and shared. Two events carry the task:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [{ "type": "command", "command": "python3 ~/.claude/skills/correct-zaaack-md-editor-mistakes/scan_md_tables.py \"$CLAUDE_PROJECT_DIR\" | python3 ~/.claude/skills/correct-zaaack-md-editor-mistakes/fix_md_tables.py" }]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [{ "type": "command", "if": "Bash(git commit*)", "command": "python3 ~/.claude/skills/correct-zaaack-md-editor-mistakes/scan_md_tables.py \"$CLAUDE_PROJECT_DIR\" | python3 ~/.claude/skills/correct-zaaack-md-editor-mistakes/fix_md_tables.py && git -C \"$CLAUDE_PROJECT_DIR\" add -A" }]
      }
    ]
  }
}
```

Three fine points about that:

**The path has to be absolute.** With an absolute root path the scanner emits absolute paths, and with that the repair tool's working directory becomes irrelevant. With a relative path both would have to run from the same directory — an unnecessary assumption inside a hook.

**The `git add -A` in the commit hook** is needed because the hook runs before the commit: without staging again, the repair does not land in the very commit it is meant to rescue. The extent `-A` matches this repository's rule of always committing the whole project; whoever commits selectively needs something else here.

**Not restricted to `*.md`.** The matcher `Edit|Write` fires after every file change, not only after Markdown ones. That is deliberate: a full pass over this repository takes 50 ms, a fifth of which is interpreter startup — a restriction would save nothing and would call for a condition syntax that was not verified here.

**One gap remains, and it is fundamental.** When the user saves in their editor, no tool of Claude's runs — so no hook on tool events fires either. Their changes only come to light when Claude next touches the file or commits. The `FileChanged` event would be meant for this but will not serve: its matcher takes literal filenames only, "Claude Code splits this value into literal filenames rather than evaluating it as a regex" ([Hooks reference](https://code.claude.com/docs/en/hooks)), and the permitted character set is confined to "letters, digits, `_`, and `|` only". For "all `*.md`" one would have to list every file individually.

### What ends up in the memory — and what does not

The skill has Claude record whether this project is affected, and **a refusal as well**. Without the second half, the question starts afresh in every session.

What is recorded is a finding about the project, not a claim about the user. The reason: artifacts in a file only prove that the file has been through such an editor — that may have been a colleague, or an old commit.

**The project memory sits under `~/.claude/projects/<project>/memory/` and holds for this project only.** In the next repository the question starts over. Whoever uses that editor everywhere is better off taking the finding into `~/.claude/CLAUDE.md`; the skill proposes that but does not write there itself.

### State of knowledge

Detection and repair are demonstrated against a test tree of edge cases: a folder name with a space and an emoji (survives the trip through JSON into the repair tool), a deliberate suffix on a code span (unchanged, by checksum comparison), `.git` excluded (likewise), a file without tables passed over. Blank test afterwards with an empty work list and exit code 0.

On the real repository: 67 Markdown files, 1,037 KB, 28 of them with tables. First clean-up run: 40 swallowed spaces and 6 no-break ones across 8 files. Runtime of the scanner over the whole tree 50 ms.

Not demonstrated is everything expressly marked "not measured" above — in particular whether the editor does damage outside tables.

### Firing: measured on 24 August 2026

Procedure per chapter 4.2 of the internal guidelines: a throwaway project with a `CLAUDE.md` carrying nothing but the trigger, and a load indicator whose `description` is the real one. Demonstrated from the stream of `claude -p --output-format stream-json --verbose`, not from the model's own account. One run per condition — a directional finding, not a proof.

| Condition | Sonnet 5 | Opus 5 |
| --- | --- | --- |
| off-topic question (must not fire) | does not fire | does not fire |
| "add a table row to `doku.md`" | fires | fires |
| "commit the changes" | fires | fires |
| asked about spaces explicitly | fires | fires |

**The trigger fires early enough.** With Opus the skill call was the very first action, with Sonnet the second — in both cases before the file was first read. That is the property chapter 2.1 insists on: a later hit no longer rescues a decision that has already been made.

**The standing authorization has no effect while it lives in the skill alone.** An A/B comparison with the same prompt, the same models and the same skill; the only thing changed was the `CLAUDE.md` entry:

| The authorizing sentence sits … | Sonnet 5 | Opus 5 |
| --- | --- | --- |
| in the skill body only | plan presented, nothing repaired | plan presented, nothing repaired |
| in the `CLAUDE.md` entry as well | repaired and reported | repaired and reported |

The reason is precedence. The rule "no file change without a plan presented first" sits in the `CLAUDE.md` and holds unconditionally; an authorization that sits in the skill body alone comes up against it and loses. Both models decided the same way without hesitating. **Whoever wants the automation has to take the authorizing sentence into the `CLAUDE.md` entry** — in the skill alone it is inert.

A side finding that confirms the limit of the authorization: in the effective version both models repaired the whitespace without asking, reported it afterwards — and still presented the *actual* task, a new table row, as a plan. So the authorization covers exactly what it names and no more. The production scanner confirmed afterwards: no findings left, the models' manual repair matched what the tool would have done.

## Status and open points

**Status.** Finished and usable. Tools verified, skill text and silent trigger written out, frontmatter set, both language versions present.

**Split checked and rejected** (25 August 2026). The division into a thin `SKILL.md` and a rules file loaded on demand (guidelines, chapter 5.2) fails here on the third condition: whether a project is affected only shows after a run of the tools, and their description is the rules part — the clarification would have to load it anyway.

**Open:**

- **Whether the editor does damage outside tables** has not been measured. Should such a case turn up, it belongs in `md_table_artifacts.py` and in this README.

**On the name.** `correct-zaaack-md-editor-mistakes` names one particular editor, although the tools ask about the damage and not about who caused it — they bite with any editor that does the same thing. A name like `md-table-whitespace` would last longer. The name is a deliberate choice and not an oversight; whoever changes it changes the folder name, the `name` in the frontmatter of both `SKILL` versions, the slash call, and the reference in both `CLAUDE-snippet` versions along with it.

**Deliberately left open:**

- **Whether a hook is set up is the target project's decision.** The skill sets none and can set none; it names one and describes the setup.
- **The content of `SKIP`** belongs to the target project. The current list is this repository's and not a recommendation.
